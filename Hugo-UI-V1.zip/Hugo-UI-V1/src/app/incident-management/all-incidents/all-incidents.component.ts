import { LiveAnnouncer } from '@angular/cdk/a11y';
import { AfterViewInit, Component, ViewChild, inject } from '@angular/core';
import { MatSort, Sort, MatSortModule } from '@angular/material/sort';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import {MatPaginator, MatPaginatorModule} from '@angular/material/paginator';

export interface PeriodicElement {
  Incident: string;
  ApplicationName: string;
  ShortDescription: string;
  InitiatedBy: string;
  CreationTime: string;
  AssignedUser: string;
  Feedback: string;
  Action: string;
}
const ELEMENT_DATA: PeriodicElement[] = [
  { Incident: '#INC12345678', ApplicationName: 'Service Now', ShortDescription: 'Login Issues', InitiatedBy: 'Walter Frazier', CreationTime: '2024-08-26 10:21:34', AssignedUser: 'Allen Webb', Feedback: '', Action: '' },
  { Incident: '#INC12345678', ApplicationName: 'Service Now', ShortDescription: 'Login Issues', InitiatedBy: 'Walter Frazier', CreationTime: '2024-08-26 10:21:34', AssignedUser: 'Allen Webb', Feedback: '', Action: '' },
  { Incident: '#INC12345678', ApplicationName: 'Service Now', ShortDescription: 'Login Issues', InitiatedBy: 'Walter Frazier', CreationTime: '2024-08-26 10:21:34', AssignedUser: 'Allen Webb', Feedback: '', Action: '' },
  { Incident: '#INC12345678', ApplicationName: 'Service Now', ShortDescription: 'Login Issues', InitiatedBy: 'Walter Frazier', CreationTime: '2024-08-26 10:21:34', AssignedUser: 'Allen Webb', Feedback: '', Action: '' },
  { Incident: '#INC12345678', ApplicationName: 'Service Now', ShortDescription: 'Login Issues', InitiatedBy: 'Walter Frazier', CreationTime: '2024-08-26 10:21:34', AssignedUser: 'Allen Webb', Feedback: '', Action: '' },
  { Incident: '#INC12345678', ApplicationName: 'Service Now', ShortDescription: 'Login Issues', InitiatedBy: 'Walter Frazier', CreationTime: '2024-08-26 10:21:34', AssignedUser: 'Allen Webb', Feedback: '', Action: '' },
];
/**
 * @title Table with sorting
 */


@Component({
  selector: 'app-all-incidents',
  templateUrl: './all-incidents.component.html',
  styleUrl: './all-incidents.component.css'
})
export class AllIncidentsComponent implements AfterViewInit {
  currentYear = new Date();

  private _liveAnnouncer = inject(LiveAnnouncer);

  displayedColumns: string[] = ['Incident', 'ApplicationName', 'ShortDescription', 'InitiatedBy', 'CreationTime', 'AssignedUser', 'Feedback', 'Action'];
  dataSource = new MatTableDataSource(ELEMENT_DATA);

  @ViewChild(MatPaginator) paginator!: MatPaginator;

  @ViewChild(MatSort) sort!: MatSort;
  tableLayout: any;

  ngAfterViewInit() {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
  }

  /** Announce the change in sort state for assistive technology. */
  announceSortChange(sortState: Sort) {
    // This example uses English messages. If your application supports
    // multiple language, you would internationalize these strings.
    // Furthermore, you can customize the message to add additional
    // details about the values being sorted.
    if (sortState.direction) {
      this._liveAnnouncer.announce(`Sorted ${sortState.direction}ending`);
    } else {
      this._liveAnnouncer.announce('Sorting cleared');
    }
  }

}
