import { Component } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})


export class LoginComponent {
  currentYear = new Date();
  show = false;
  

  ngOnInit(): void {
    
  }

  loginSubmit(){
    //this.router.navigate(['/issueInvesitigation']);
  }

  onClick() {
    var x = <any>document.getElementById("loginPassword");
    if (x.type === 'password') {
      x.type = 'text';
      this.show = true;
    } else {
      x.type = 'password';
      this.show = false;
    }
  }
}
