import { Component } from '@angular/core';
import $ from 'jquery';

@Component({
  selector: 'app-nav-menu',
  templateUrl: './nav-menu.component.html',
  styleUrl: './nav-menu.component.css'
})
export class NavMenuComponent {
  currentYear = new Date();


  toggleSidebarNav() {
    $('body').toggleClass('toggle-sidebar');
  }
}
