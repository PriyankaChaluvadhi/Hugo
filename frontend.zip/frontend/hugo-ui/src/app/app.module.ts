import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { authGuard } from './_helpers/auth.guard';
import { NavMenuComponent } from './nav-menu/nav-menu.component';
import { AllIncidentsComponent } from './incident-management/all-incidents/all-incidents.component';
import { MatTableModule } from '@angular/material/table';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    NavMenuComponent,
    AllIncidentsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MatButtonModule,
    MatInputModule,
    MatTableModule,
    MatSelectModule,
    MatPaginatorModule,
    MatSortModule,
    RouterModule.forRoot([
      //, canActivate: [authGuard] 
      { path: 'All-Incidents', component: AllIncidentsComponent, title: 'All Incidents'},
      { path: 'login', component: LoginComponent, title: 'Login' },
      { path: '', component: LoginComponent },
      // otherwise redirect to home
      { path: '**', redirectTo: '' }

    ])
  ],
  providers: [
    provideClientHydration(),
    provideAnimationsAsync()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
