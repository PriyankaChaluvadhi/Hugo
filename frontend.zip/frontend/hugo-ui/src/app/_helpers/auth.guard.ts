import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';

export const authGuard: CanActivateFn = (route, state) => {
  const router = inject(Router);

  router.navigate(['/login']);
  return false;
};




// export const authGuard: CanActivateFn = (
//   route: ActivatedRouteSnapshot,
//   state: RouterStateSnapshot
// ) => {
//   const platformId = inject(PLATFORM_ID);
//   const authenticationService = inject(AuthenticationService);
//   const router = inject(Router);

//   if(isPlatformBrowser(platformId)) {
//       if (authenticationService.isLogin()) {
//           return true;
//       } else {
//           router.navigate(['/authentication']);
//           return false;
//       }
//   }
//   return false;
// };




// import { Injectable } from '@angular/core';
// import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

// import { AuthenticationService } from '../services/authentication.service';

// @Injectable({ providedIn: 'root' })
// export class AuthGuard implements CanActivate {
//     constructor(
//         private router: Router,
//         private authenticationService: AuthenticationService
//     ) { }

//     canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
//         const currentUser = this.authenticationService.currentUserValue;
//         if (currentUser) {
//             // logged in so return true
//             return true;
//         }

//         // not logged in so redirect to login page with the return url
//         //this.router.navigate(['/login'], { queryParams: { returnUrl: state.url } });
//         this.router.navigate(['/login']);
//         return false;
//     }
// }